﻿<#
    Infrastructure Tessing - Summit 2017
    testing AD 
 #>

## need the AD provider
Import-Module ActiveDirectory

Describe 'Test AD' {
  It 'W16DC01 should be online' {
    Test-Connection -ComputerName W16DC01 -Quiet | Should Be $true
  }

  It 'W16DC01 should be a Doman Controller' {
    Get-ADDomainController | select -ExpandProperty Name | Should BeIn @('W16DC01')
  }

  It 'W16DC01 should be a Global catalog' {
    (Get-ADDomainController -Identity W16DC01).IsGlobalcatalog | Should Be $true
  }
<# 
   testing for existance
      AD cmdlets error if object NOT present
      try
        Get-ADGroup -Identity JEA_WSUS_Report2 -ErrorAction SilentlyContinue
        Need to set $ErrorActionPreference

      use Should Exist - effectively running a Test-Path
#> 
  It 'Group JEA_WSUS_Report should exist' {
    "AD:\CN=JEA_WSUS_Report,OU=Groups,DC=Manticore,DC=org" | 
    Should Exist      
  }
  It 'Group JEA_WSUS_Report2 should NOT exist' {
    "AD:\CN=JEA_WSUS_Report2,OU=Groups,DC=Manticore,DC=org" | 
    Should Not Exist      
  }
<#
   testing user is similar
#>
  It 'user Bill Green should exist' {
    "AD:\CN=GREEN Bill,OU=UserAccounts,DC=Manticore,DC=org" | 
    Should Exist      
  }
  It 'user account Bill Green  should be enabled' {
    Get-ADUser -Identity billgreen | select -Expand Enabled | 
    Should Be $true      
  }
 }