﻿<#
    Infrastructure Tessing - Summit 2017
    testing machines online
 #>

 Describe 'Ping test' {

##  tests DNS lookup & ping  
  It 'W16DSC01 should be online' {
    Test-Connection -ComputerName W16DSC01 -Quiet | 
    Should Be $true
  }
}
Describe 'DNS lookup' {
<#
  testing dns 
    resource record ?
    Get-DnsServerResourceRecord -ZoneName manticore.org -Name W16DSC01 -ComputerName W16DC01 | fl *
#>
  It 'W16DSC01 should be in DNS' {
    (Get-DnsServerResourceRecord -ZoneName manticore.org -RRType A -Name W16DSC01 -ComputerName W16DC01).RecordData.IPv4Address.IPAddressToString |
    Should Be '10.10.54.21' 
  }
  
  It 'W16DSC01 should be resolvable' {
    (Resolve-DnsName -Name W16DSC01).IPAddress |
    Should Be '10.10.54.21' 
  }
}
Describe 'Test ports' {
<#
  might also want to test ports
#>
  It 'W16DSC02 should be listening on port 80' {
    (Test-NetConnection -ComputerName W16DSC02 -Port 80).TcpTestSucceeded |
    Should Be $true
  }
  It 'W16DSC02 should be listening on port 443' {
    (Test-NetConnection -ComputerName W16DSC02 -Port 443).TcpTestSucceeded |
    Should Be $true
  }
 }

 <#
    using cmdlet
    comemnted out so doesn't run
    when run script
 #>
 ## invoke ALL tests
 <#
 Invoke-Pester -Script C:\Scripts\TestingInfratsructure-Summit2017\IT-Test2-TestingNetCon.ps1
 #>

 ## invoke A test
 ## use the Describe name
 <#
 Invoke-Pester -Script C:\Scripts\TestingInfratsructure-Summit2017\IT-Test2-TestingNetCon.ps1 -TestName 'Test ports'
 #>

 ## output object
 ## and inspect results
 <#
 $tests = Invoke-Pester -Script C:\Scripts\TestingInfratsructure-Summit2017\IT-Test2-TestingNetCon.ps1 -TestName 'Test ports' -PassThru
 $tests
 $tests.TestResult
 $tests.TestResult | where Result -eq 'Failed'
 #>