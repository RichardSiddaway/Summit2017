﻿<#
    Infrastructure Testing - Summit 2017
    testing web site
 #>

 ## create remoting session
 $s = New-PSSession -ComputerName W16DSC02
 Invoke-Command -Session $s -ScriptBlock {Import-Module WebAdministration}

 <#
   RUN this to see issue
   Invoke-Command -ComputerName W16DSC02 -ScriptBlock {
     Get-Service -Name W3SVC | select -ExpandProperty Status
   }

   Need to extract Value
   CHECK ALL REMOTING CALLS
 #>


 Describe 'Test IIS' {
   
   It 'IIS should be running' {
     
     (Invoke-Command -Session $s -ScriptBlock {
      Get-Service -Name W3SVC | select -ExpandProperty Status
     }).Value  | Should Be 'Running' 
   
   }

   It 'No extra web sites created' {

     Invoke-Command -Session $s -ScriptBlock {Get-Website | select Name} | 
     select -ExpandProperty Name | 
     Should BeIn  @('Default Web Site', 'PullServer', 'ComplianceServer') 

   }

   ## using IIS provider and should Exist 
   ##   doesn't work so ...

   $site = Invoke-Command -Session $s -ScriptBlock {
     Get-Website -Name Pullserver
   }

   ## thisis case sensitive!!
   It 'PullServer web site exists' {

     $site.Name | Should BeExactly 'PullServer'

   }

   It 'PullServer site running' {

     $site.State | Should Be 'Started'

   }

   It 'PullServer site running' {

     $site.State | Should Be 'Started'

   }

   It 'PullServer should be listening on HTTPS' {

     $site.bindings.Collection.protocol | 
     Should Be 'https'

   }

   ##  yay - I'm actully using a regex
   It 'PullServer should be listening on port 8080' {

     $site.bindings.Collection.BindingInformation | 
     Should Match '8080'

   }

 } ## end of Describe

 Remove-PSSession $s

  <#
 demonstrate running all *.Tests.ps1 scripts in one hit
 
   Invoke-Pester -Script C:\Scripts\TestingInfratsructure-Summit2017
    
 #>