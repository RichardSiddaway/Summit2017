﻿<#
   Infrastructure testing with
   operational validation framework
#>
Get-Command -Module "*operation*"

## view tests
Get-OperationValidation -ModuleName IT-Summit2017 

Get-OperationValidation -ModuleName IT-Summit2017 -TestType Simple

Get-OperationValidation -ModuleName IT-Summit2017 -TestType Comprehensive

## view module structure
## note Diagnostics folder and
##  naming of test files
Get-ChildItem -Path C:\Scripts\Modules\IT-Summit2017 -Recurse

## view tests
Get-Content -Path C:\Scripts\Modules\IT-Summit2017\1.0.0\Diagnostics\Simple\Simple.Tests.ps1

## running test
Invoke-OperationValidation -ModuleName IT-Summit2017 -TestType Simple