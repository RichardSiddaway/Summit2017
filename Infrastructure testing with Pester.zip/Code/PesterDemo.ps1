﻿function factorial {
  param(
    [int]$value
  )
  $result = 1
  1..$value | foreach {
    $result *= $psitem
  }
  $result
}

Describe factorial {
  Context three {
    It 'Calculates correctly' {
      factorial 3 | Should BeExactly 6
    }
    It 'Auto converts strings' {
      factorial '3' | Should BeExactly 6    
    }
    It 'Handles negative numbers' {
      factorial -3 | Should Be 0
    }
  }
  Context 'big numbers' {
    It 'calculates for 20' {
      factorial 20 | Should Be 2.43290200817664E+18
    }
    It 'calculates for 200' {
      factorial 200 | Should Be ([double]::MaxValue)
    }
  }
}

## get a bit more information if use Invoke-Pester
#Set-Location -Path 'C:\MyData\2017 Summit\Infrastructure Testing\Demo'
#Invoke-Pester -Script .\PesterDemo.ps1