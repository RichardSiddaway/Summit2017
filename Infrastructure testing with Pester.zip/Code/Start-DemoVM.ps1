﻿<#
  Infrastructure Testing - Summit 2017
    Start demo VMs
#>
$computers = 'W16DC01', 'W16AS01', 'W16TGT01', 'W16DSC02'

foreach ($computer in $computers) {
  Start-VM -Name $computer -Verbose
  Start-Sleep -Seconds 180
}