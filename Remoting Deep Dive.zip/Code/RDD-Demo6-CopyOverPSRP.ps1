﻿<#
  Remoting Deep Dive - Summit 2017
    Copying files over a remoting session
    can copy to ALL machines participating in a session
#>
##
## OPEN IN SEPARATE SESSION
##
$s = New-PSSession -ComputerName W16TGT01

## test for file
$sb = {Test-Path C:\Scripts\test.txt}
Invoke-Command -Session $s -ScriptBlock $sb

## copy file
Copy-Item -Path C:\Scripts\test.txt -Destination C:\Scripts -ToSession $s -Force

## retest for file
Invoke-Command -Session $s -ScriptBlock $sb 

## copying a folder FROM a session
Get-ChildItem -Path C:\Scripts
Copy-Item -Path C:\Scripts\HyperV\ -Destination C:\Scripts -Recurse -Force -FromSession $s

Get-ChildItem -Path C:\Scripts
Get-ChildItem -Path C:\Scripts\HyperV -Recurse

## clean up
$sb = {Remove-Item -Path C:\Scripts\test.txt -Force} 
Invoke-Command -Session $s -ScriptBlock $sb

Remove-Item -Path C:\Scripts\HyperV -Recurse -Force

Remove-PSSession -Session $s

## ANY thoughts on good usage for this???