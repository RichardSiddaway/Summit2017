﻿<#
  Remoting Deep Dive - Summit 2017
    Creating a JEA end point
#>
##
## OPEN IN SEPARATE SESSION
##
Set-Location -Path C:\Scripts\RDD-Summit2017

## Create Role file
##   role file is read when 
##   making connection to JEA endpoint
New-PSRoleCapabilityFile -Path  .\WSUSJEARole.psrc -ModulesToImport UpdateServices `
-VisibleCmdlets @{Name='Get-WsusComputer'; Parameters=@{Name = 'ComputerTargetGroups'; ValidateSet = 'Windows 2016' }} `
-VisibleExternalCommands 'C:\Scripts\RDD-Summit2017\Get-UpdateStatus.ps1'

Get-Content .\WSUSJEARole.psrc

##
## create module
##  USE PROGRAM FILES
##  TO MAKE VISIBLE AND 
##  RESTRICT ACCESS
##

## create module
New-Item -Path 'C:\Program Files\WindowsPowerShell\Modules' -Name WSUSJEA -ItemType Directory -Force

New-Item -Path 'C:\Program Files\WindowsPowerShell\Modules\WSUSJEA' -Name RoleCapabilities -ItemType Directory -Force
Copy-Item -path .\WSUSJEARole.psrc -Destination 'C:\Program Files\WindowsPowerShell\Modules\WSUSJEA\RoleCapabilities' -Force

New-ModuleManifest -Path 'C:\Program Files\WindowsPowerShell\Modules\WSUSJEA\WSUSJEA.psd1' -RootModule 'WSUSJEA.psm1' 

## current session configuration
Get-PSSessionConfiguration | Select-Object Name

## create a session configuration file
##  notice session type
New-PSSessionConfigurationFile -SessionType RestrictedRemoteServer -Path .\WSUSJEAEndpoint.pssc `
-RunAsVirtualAccount -RunAsVirtualAccountGroups 'WSUS Administrators' `
-RoleDefinitions @{'Manticore\JEA_WSUS_Report' = @{Rolecapabilities = 'WSUSJEARole' }}

Test-PSSessionConfigurationFile -Path .\WSUSJEAEndpoint.pssc

## registering configuration causes WinRM to restart
Register-PSSessionConfiguration -Path .\WSUSJEAEndpoint.pssc -Name 'JEAWSUSReport' -Force

Get-PSSessionConfiguration | Select-Object Name

Get-PSSessionConfiguration -Name JEAWSUSReport
Get-PSSessionConfiguration  -Name 'microsoft.powershell'