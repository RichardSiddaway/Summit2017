﻿<#
  Remoting Deep Dive - Summit 2017
    CIM sessions
#>
##
## CIM cmldets came with PowerShell v3
Get-CimInstance -ClassName Win32_OperatingSystem -ComputerName W16TGT01

## use WSMAN
Test-WSMan -ComputerName W16TGT01
## with OS info
Test-WSMan -ComputerName W16TGT01 -Authentication Default

## create CIM session
##  MUST be WSMAN 3.0 (or higher?) [Stack property]
Get-Command New-CimSession -Syntax

$cs1 = New-CimSession -ComputerName W16TGT01
$cs1

Get-CimInstance -ClassName Win32_OperatingSystem -CimSession $cs1

## use -Computername for 1 off
## use CimSession for multiple requests

$cs2 =  New-CimSession -ComputerName W16DC01, W16PWA01
Get-CimSession | Format-Table -AutoSize

## working with multiple sessions
## not this - bug?
## Get-CimInstance -ClassName Win32_OperatingSystem -CimSession $cs1, $cs2

$allsess = Get-CimSession
Get-CimInstance -ClassName Win32_OperatingSystem -CimSession $allsess

## can use DCOM if have to
$csdopt = New-CimSessionOption -Protocol Dcom
$csd = New-CimSession -ComputerName W16CN01 -SessionOption $csdopt
Get-CimSession | Format-Table

## can use together
Get-CimInstance -ClassName Win32_OperatingSystem -CimSession (Get-CimSession)

## CDXML cmdlets don't have -computerName
##   just CIMsession
##   CIM class MUST be on remote machine
Get-Command Get-NetAdapter -Syntax
Get-NetAdapter -CimSession (Get-CimSession)

## non domain machine - cheating
##   also works for Linux and network switches!
##   but use IP address if not in DNS
<#
$params = @{
    ComputerName = '10.10.54.70'
    Credential = New-Object pscredential -ArgumentList root, $pwd
    Authentication = 'Basic'
    SessionOption = New-CimSessionOption -UseSsl -SkipCACheck -SkipCNCheck -SkipRevocationCheck
}
#> 
$cred = Get-Credential -Credential W16ND01\Administrator
$params = @{
    ComputerName = 'W16ND01'
    Credential = $cred
    SessionOption = New-CimSessionOption -UseSsl -SkipCACheck -SkipCNCheck -SkipRevocationCheck
}
$csA = New-CimSession @params
$csA

Get-CimInstance -ClassName Win32_OperatingSystem -CimSession (Get-CimSession)

## using SSL correctly
$params2 = @{
    ComputerName = 'W16ND01'
    Credential = $cred
    SessionOption = New-CimSessionOption -UseSsl 
}
$csA2 = New-CimSession @params2
$csA2

## notice get one hit per session - no filter on duplicate machines
Get-CimInstance -ClassName Win32_OperatingSystem -CimSession (Get-CimSession)

## clean up
Get-CimSession | Remove-CimSession