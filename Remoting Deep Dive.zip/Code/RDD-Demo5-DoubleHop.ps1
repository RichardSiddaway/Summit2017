﻿<#
  Remoting Deep Dive - Summit 2017
    Double hop problem
#>
##
## OPEN IN SEPARATE SESSION
##

<#
  Basic problem is can't access third machine
#>
## access remote machine
Invoke-Command -ComputerName w16TGT01 -ScriptBlock {Get-Process}

## now try double hop
Clear-Host
Invoke-Command -ComputerName w16TGT01 -ScriptBlock {
  Invoke-Command -ComputerName w16CN01 -ScriptBlock {Get-Process}
}

## can go direct
Clear-Host
Invoke-Command -ComputerName w16CN01 -ScriptBlock {Get-Process}

## need credentials
$rscred = Get-Credential -Credential manticore\richard

<# 
  for one off delegate credentials manually
#>
Invoke-Command -ComputerName w16TGT01 -ScriptBlock {
  param ($cred)
  Invoke-Command -ComputerName w16CN01 -Credential $cred -ScriptBlock {Get-Process}
  Invoke-Command -ComputerName w16CN01 -Credential $cred -ScriptBlock {Get-ChildItem -Path Env:COMPUTERNAME | select Key, Value}
} -ArgumentList $rscred

<#
 CREDSSP - Enable CredSSP on remote machine AND this machine

 run 
   Enable-WSManCredSSP -Role Server
    on remote machine

OR:
#>
Connect-WSMan -ComputerName w16TGT01

Get-ChildItem -Path wsman:
Get-ChildItem -Path wsman:\w16tgt01\Service\Auth

Set-Item -Path WSMan:\w16tgt01\Service\Auth\CredSSP -Value $true

<#
 delegate credentials
  notice warning 
  bypass with -Force
#>
Get-WSManCredSSP
Enable-WSManCredSSP -Role Client -DelegateComputer W16TGT01
Get-WSManCredSSP

Invoke-Command -ComputerName w16TGT01 -ScriptBlock {
  Get-WSManCredSSP
}

## retry double hop
##   this is what you used ....
Clear-Host
Invoke-Command -ComputerName w16TGT01 -ScriptBlock {
  Invoke-Command -ComputerName w16CN01 -ScriptBlock {Get-Process}
}

<#
need to specify CredSSP and supply credentials
  COMPUTERNAME MUST match in invoke-command and Enable-WSManCredSSP
#>
Invoke-Command -ComputerName w16TGT01 -Authentication Credssp -Credential $rscred -ScriptBlock {
  Invoke-Command -ComputerName w16CN01 -ScriptBlock {Get-Process}
  Invoke-Command -ComputerName w16CN01 -ScriptBlock {Get-ChildItem -Path Env:COMPUTERNAME | select Key, Value}
}
<#
  New-Pssession can be configured to use CredSSP

  RECOMMENDATION
    DON'T LEAVE CREDSSP PERMANENTLY ENABLED
#>
Disable-WSManCredSSP -Role Client 
Set-Item -Path WSMan:\w16tgt01\Service\Auth\CredSSP -Value $false
Disconnect-WSMan -ComputerName w16TGT01


