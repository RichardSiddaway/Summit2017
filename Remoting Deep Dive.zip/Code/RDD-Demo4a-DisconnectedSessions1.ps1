﻿<#
  Remoting Deep Dive - Summit 2017
    Disconnected sessions part 1
#>
##
## OPEN IN SEPARATE SESSION
##
## no sessions present
Get-PSSession

## create sessions
$s1 = New-PSSession -ComputerName W16TGT01

## use session
Invoke-Command -Session $s1 -ScriptBlock {Get-Process -Name spoolsv}

## multiple machines
$s2 = New-PSSession -ComputerName W16DSC01, W16DSC02
Invoke-Command -Session $s2 -ScriptBlock {Get-Process -Name spoolsv}

## disconnect sessions
Get-PSSession
Get-PSSession | Disconnect-PSSession