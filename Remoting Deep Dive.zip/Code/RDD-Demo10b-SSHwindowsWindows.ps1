﻿##   DOESN'T SEEM TO WORK 
##
## Run IN PowerShell v6 SESSION
##

## create SSH session to Windows
$nds = New-PSSession -HostName W16ND01 -UserName administrator

## notice Configuration names
Get-PSSession

#using a SSH session
$sb = {Get-ChildItem -Path env:}
Invoke-Command -Session $nds -ScriptBlock $sb

## all together now
Invoke-Command -Session $lxs, $ws, $nds -ScriptBlock $sb

Get-PSSession | Remove-PSSession