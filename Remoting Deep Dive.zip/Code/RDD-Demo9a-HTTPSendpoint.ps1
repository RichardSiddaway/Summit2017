﻿<#
  Remoting Deep Dive - Summit 2017
    create HTTPs listener
#>
##
##  current listeners
Get-ChildItem -Path WSMan:\localhost\Listener\

## get certificate
Get-ChildItem -Path Cert:\LocalMachine\My\ 

## get thumbprint
$tp = Get-ChildItem -Path Cert:\LocalMachine\My\ |
where Subject -eq 'CN=W16AS01' |
select -ExpandProperty Thumbprint

$tp

## create listener
New-WSManInstance -ResourceURI winrm/config/Listener -SelectorSet @{Address="*";Transport="HTTPS"} `
-ValueSet @{HostName="W16AS01";CertificateThumbprint="$tp"}

##  listeners
Get-ChildItem -Path WSMan:\localhost\Listener\

##  listener details
Get-WSManInstance -ResourceURI winrm/config/Listener -SelectorSet @{Address="*";Transport="HTTPS"}

##
##  may need to create a firewall rule to allow HHTPS remoting
##   port based rule for 5986
$pr = Get-NetFirewallPortFilter -Protocol TCP  | 
where LocalPort -eq 5986

Get-NetFirewallRule -AssociatedNetFirewallPortFilter $pr

## now try connecting from W16TGT01

##
##  now remove the listener
Remove-WSManInstance -ResourceURI winrm/config/Listener -SelectorSet @{Address="*";Transport="HTTPS"}

##
## check listener
Get-ChildItem -Path WSMan:\localhost\Listener\