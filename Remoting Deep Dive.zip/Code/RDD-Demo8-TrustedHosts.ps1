﻿<#
  Remoting Deep Dive - Summit 2017
    Trusted hosts use
#>
##
## OPEN IN SEPARATE SESSION
##
Get-ChildItem -Path WSMan:\localhost\Client
Set-Item -Path WSMan:\localhost\Client\AllowUnencrypted -Value $true -Force
Set-Item -Path WSMan:\localhost\Client\TrustedHosts -Value 'W16ND01' -Force
Get-ChildItem -Path WSMan:\localhost\Client

$cred =  Get-Credential W16ND01\Administrator

$s = New-PSSession -ComputerName W16ND01 -Credential $cred

$sb = {
 $env:COMPUTERNAME
 Get-Process
}
Invoke-Command -Session $s -ScriptBlock $sb

## CIM sessions 
$cs = New-CimSession -ComputerName W16ND01 -Credential $cred

Get-NetAdapter -CimSession $cs

## clean up
Remove-PSSession $s
Remove-CimSession $cs
Set-Item -Path WSMan:\localhost\Client\AllowUnencrypted -Value $false -Force
Set-Item -Path WSMan:\localhost\Client\TrustedHosts -Value '' -Force
Get-ChildItem -Path WSMan:\localhost\Client