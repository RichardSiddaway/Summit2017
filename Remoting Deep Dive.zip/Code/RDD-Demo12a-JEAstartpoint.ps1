﻿<#
  Remoting Deep Dive - Summit 2017
    JEA1 - accessing everything over a remote session
#>
##
##  can access anything through a remote session
##    IF YOU HAVE THE UNDERLYING PERMISSIONS
##
$s = New-PSSession -ComputerName W16AS01

$sb = {
   Get-Module -ListAvailable
}
Invoke-Command -Session $s -ScriptBlock $sb

$sb = {
   Get-Command -Module UpdateServices
}
Invoke-Command -Session $s -ScriptBlock $sb

$sb = {
   Get-WsusComputer -ComputerTargetGroups 'Windows 2016'
}
Invoke-Command -Session $s -ScriptBlock $sb

## see updates
$sb = {
   C:\Scripts\RDD-Summit2017\Get-UpdateStatus.ps1
}
Invoke-Command -Session $s -ScriptBlock $sb

Get-PSSession | Remove-PSSession
##
##  OUCH 
##    can control WSUS
##  IDEALLY just want them to:
##    view WSUS computers
##    view updates status
##
##    Enter JEA stage right