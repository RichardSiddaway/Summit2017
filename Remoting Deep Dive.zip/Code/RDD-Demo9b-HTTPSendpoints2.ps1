﻿<#
  Remoting Deep Dive - Summit 2017
    using SSL
#>
##
##  standard remoting
##
$shttp = New-PSSession -ComputerName W16AS01
$shttp

##  HTTP = port 5985; HTTP = port 5986
##  test W16AS01 is listening on port 5986
Test-NetConnection -ComputerName w16AS01 -Port 5986

$shttpS = New-PSSession -ComputerName W16AS01 -UseSSL 
$shttpS

## use as normal
Invoke-Command -Session $shttpS -ScriptBlock {Get-Process}

Get-PSSession | Remove-PSSession 

###
###  now try non-domain machine
Test-NetConnection -ComputerName W16ND01 -Port 5986

$cred = Get-Credential W16ND01\Administrator
$nd = New-PSSession -ComputerName W16ND01 -UseSSL -Credential $cred
$nd
Invoke-Command -Session $nd -ScriptBlock {Get-Process}

Get-PSSession | Remove-PSSession