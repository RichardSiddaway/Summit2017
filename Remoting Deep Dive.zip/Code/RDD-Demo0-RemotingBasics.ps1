﻿<#
  Remoting Deep Dive - Summit 2017
    remoting basics
#>
##
## OPEN IN SEPARATE SESSION
##
### view standard endpoints
Get-PSSessionConfiguration

### view WSMAN
###    need Stack 3.0 for CIM sessions
Test-WSMan
Test-WSMan -Authentication Default
Test-WSMan -Authentication Default -ComputerName W16TGT01
 
### network profiles
###    use Set-NetConnectionProfile to change if needed
Get-NetConnectionProfile

## data is deserialized
##   NO methods
##
##  local machine
Get-Process | Get-Member
## remote machine
Invoke-Command -ComputerName W16TGT01 -ScriptBlock {Get-Process} | Get-Member