﻿<#
  Remoting Deep Dive - Summit 2017
    PowerShell Web Access
#>
## install PowerShell Web Access
<#
### ALREADY DONE FOR SPEED IN DEMO
###
Install-WindowsFeature -Name Web-WebServer, Web-Mgmt-Console, NET-Framework-45-ASPNET, Web-Net-Ext45, 
          Web-ISAPI-Ext, Web-ISAPI-Filter, Web-Default-Doc, Web-Http-Errors, Web-Http-Redirect, 
          Web-Static-Content, Web-Filtering, WindowsPowerShellWebAccess -Confirm:$false
#>
##
## PowerShell Web Access cmdlets
Get-Command -Module PowerShellWebAccess
##
## create pwa web application using defaults
##   USE A PROPER SSL CERTIFICATE in production
##    needs to be third party if machines outside
##    domain will access the web access gateway
## Install-PswaWebApplication -WebApplicationName PSG  -UseTestCertificate
##

##  lets do this properly
##   SSL certificate installed
Get-ChildItem -Path Cert:\LocalMachine\My

##
## install web application
##   in default web site
#Install-PswaWebApplication -WebApplicationName PSG 

##
##  Add SSL cert to web site Bindings
##

## 
## Add authorisation rule
##  for standard remoting endpoint
#Add-PswaAuthorizationRule -RuleName "RS W16AS01" -ComputerName w16as01.manticore.org   `
#-UserName manticore\richard -ConfigurationName microsoft.powershell

## view the rule
Get-PswaAuthorizationRule
Get-PswaAuthorizationRule | Format-List *

##
## test the rule
Test-PswaAuthorizationRule -ComputerName W16AS01 -UserName manticore\richard
Test-PswaAuthorizationRule -ComputerName W16AS01 -UserName manticore\fred      ## user doesn't exist
Test-PswaAuthorizationRule -ComputerName W16AS01 -UserName manticore\billgreen    ## no rule

##
## test use from W16ND01
##
##  login as me
##  try login as Bill Green

##
## NOW we create connection to constrained endpoint
##
##
##  CAN USE GROUPS INSTEAD OF INDIVIDUALS
##    -UserGroupName<String[]>
Add-PswaAuthorizationRule -RuleName "W16AS01 Restricted endpoint" -ComputerName w16as01.manticore.org -UserName manticore\billgreen `
 -ConfigurationName WSUSdelegated -Force

## test rule
##   I don't get access
Test-PswaAuthorizationRule -ComputerName W16AS01 -ConfigurationName WSUSdelegated -UserName manticore\richard -Verbose
Test-PswaAuthorizationRule -ComputerName W16AS01 -ConfigurationName WSUSdelegated -UserName manticore\billgreen -Verbose

## view rules
Get-PswaAuthorizationRule

##
## test use from W16ND01
##   NEED TO RECREATE IE SESION
##  login as me
##  login as Bill Green  -  need to set endpoint in PWA ie logon dialog


##
## connect to JEA endpoint
## 
Add-PswaAuthorizationRule -RuleName "W16AS01 JEA endpoint" -ComputerName w16as01.manticore.org `
-UserName manticore\billgreen -ConfigurationName JEAWSUSReport -Force

Get-PswaAuthorizationRule 

##
## clean out Bill's ruleS
Get-PswaAuthorizationRule | 
where User -eq 'manticore\billgreen' |
Remove-PswaAuthorizationRule 

Get-PswaAuthorizationRule