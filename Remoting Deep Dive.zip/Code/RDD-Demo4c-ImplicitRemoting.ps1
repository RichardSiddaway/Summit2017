﻿<#
  Remoting Deep Dive - Summit 2017
    Implicit remoting
#>
##
##  standard remoting
##
Invoke-Command -ComputerName W16AS01 -ScriptBlock {Get-WSUScomputer | select FullDomainName, IPAddress, OSDescription, LastSyncTime }
Invoke-Command -ComputerName W16AS01 -ScriptBlock {Get-Command -Module UpdateServices }
##
## don't have the command locally
##
Get-Command Get-WSUSComputer

##
## can import the module from 
##   remote machine into session
##
$s = New-PSSession -ComputerName W16AS01

Get-Module -ListAvailable -Name UpdateServices -PSSession $s | Format-List

Import-Module -PSSession $s -Name UpdateServices

Get-Module
Get-Command -Module UpdateServices

## view function
Get-ChildItem -Path Function:\Get-WsusComputer

## notice $scriptcmd in definition
Get-ChildItem -Path Function:\Get-WsusComputer | select -ExpandProperty Definition

## use command
Get-WsusComputer | select FullDomainName, IPAddress, OSDescription, LastSyncTime 

## close remoting sessoin
Remove-PSSession -Session $s

## retry command 
##   recreates the remoting session
Get-WsusComputer | select FullDomainName, IPAddress, OSDescription, LastSyncTime 

## module location
$path = Get-Module UpdateServices | select -ExpandProperty path

$modpath = Split-Path -Path $path -Parent
Get-ChildItem -Path $modpath

Remove-Module UpdateServices

## and its  gone
Get-ChildItem -Path $modpath

##
##  can also use Import-PSSession
$s = New-PSSession -ComputerName W16AS01
Invoke-Command -Session $s {Import-Module UpdateServices}
$mymod = Import-PSSession -Session $s  -Module UpdateServices

$mymod

Get-Module $mymod.Name
Get-Command -Module $mymod.Name

$mymod.Path

$modpath = Split-Path -Path $mymod.Path -Parent
Get-ChildItem -Path $modpath

Get-WsusComputer | select FullDomainName, IPAddress, OSDescription, LastSyncTime 

Remove-PSSession $s 

## its gone
##   on older versions of Windows temporary module can remain
Get-WsusComputer | select FullDomainName, IPAddress, OSDescription, LastSyncTime 

Get-ChildItem -Path $modpath

###
###  alternative 
###
$s = New-PSSession -ComputerName W16AS01
Invoke-Command -Session $s {Import-Module UpdateServices}

## export cmdlets
##  and persist
Export-PSSession -Session $s -CommandName *-WSUS* -OutputModule RemoteWSUS -AllowClobber

Remove-PSSession $s

Get-Module -ListAvailable *wsus*

Import-Module -Name RemoteWSUS

Get-Command -Module RemoteWSUS

Get-WsusComputer
Get-WsusComputer | select FullDomainName, IPAddress, OSDescription, LastSyncTime 

Remove-Module RemoteWSUS
Remove-Item -Path "C:\Users\Richard\Documents\WindowsPowerShell\Modules\RemoteWSUS" -Force -Recurse