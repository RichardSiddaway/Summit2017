﻿Get-WsusUpdate -Approval AnyExceptDeclined |
sort InstalledOrNotApplicablePercentage |
foreach {
  New-Object -TypeName PSObject -Property @{
    Title = $_.Update.Title
    Approved = $_.Approved
    Classification = $_.Classification
    Installed = $_.InstalledOrNotApplicablePercentage
  }
}

## building a calculated field doesn't work
<#
select @{N='Title'; E={$_.Update.Title}},
  Approved, Classification, 
  @{N='Installed'; E={$_.InstalledOrNotApplicablePercentage}}
#>