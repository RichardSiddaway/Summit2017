﻿<#
  Remoting Deep Dive - Summit 2017
    Remoting sessions
#>
##
## OPEN IN SEPARATE SESSION  
##
## create sessions
$s1 = New-PSSession -ComputerName W16TGT01

## view session
$s1

## use session
Invoke-Command -Session $s1 -ScriptBlock {Get-Process -Name spoolsv}

## show interactive remoting

## run script on remote machine
Invoke-Command -Session $s1 -ScriptBlock {C:\Scripts\hello.ps1}

## run script from local machine
Invoke-Command -Session $s1 -FilePath C:\Scripts\hello.ps1

## multiple machines
$s2 = New-PSSession -ComputerName W16DSC01, W16DSC02
$s2

Invoke-Command -Session $s2 -ScriptBlock {Get-Process -Name spoolsv}

## pick a session
Get-PSSession
Get-PSSession -ComputerName W16DSC02

$s3 = Get-PSSession -ComputerName W16DSC02
Invoke-Command -Session $s3 -ScriptBlock {Get-Process -Name spoolsv}

## combine sessions
##  this is what you might try
$sa = @($s1,$s2)
$sa
Invoke-Command -Session $sa -ScriptBlock {Get-Process -Name spoolsv}

## wrong type
## compare
$sa | Get-Member
## and
$s2 | Get-Member

## so either
Invoke-Command -Session (Get-PSSession) -ScriptBlock {Get-Process -Name spoolsv}

$s2 += $s1
$s2
Invoke-Command -Session $s2 -ScriptBlock {Get-Process -Name spoolsv}

## OR
$computers = 'W16TGT01', 'W16DSC02'
Invoke-Command -Session (Get-PSSession -ComputerName $computers) -ScriptBlock {Get-Process -Name spoolsv}

## multiple sessions to same computer breaks things
$s2 += $s3
$s2
Invoke-Command -Session $s2 -ScriptBlock {Get-Process -Name spoolsv}

## normally remove sessions
# Get-PSSession | Remove-PSSession

##if close powershell then sesson lost