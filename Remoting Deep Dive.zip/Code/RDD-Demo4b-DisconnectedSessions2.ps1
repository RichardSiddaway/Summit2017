﻿<#
  Remoting Deep Dive - Summit 2017
     Disconnected sessions part 2
#>
##
## OPEN IN SEPARATE SESSION
##
## get any sessions
Get-PSSession 

## need computer name
Get-PSSession -ComputerName W16TGT01
Get-PSSession -ComputerName W16TGT01, W16DSC01, W16DSC02

$s1 = Connect-PSSession -ComputerName W16TGT01
Get-PSSession -ComputerName W16TGT01, W16DSC01, W16DSC02
Invoke-Command -Session $s1 -ScriptBlock {Get-Process -Name spoolsv}
Get-PSSession

$s2 = Connect-PSSession -ComputerName W16DSC01, W16DSC02
$s2
Invoke-Command -Session $s2 -ScriptBlock {Get-Process -Name spoolsv}
Get-PSSession

Get-PSSession | Remove-PSSession

## create and use disconnected session directly
##  run command and get results later
Invoke-Command -ComputerName W16CN01 -InDisconnectedSession -ScriptBlock {Get-Process -Name spoolsv}
Get-PSSession
Get-PSSession -ComputerName W16CN01
$src = Connect-PSSession -ComputerName W16CN01
$src

## could just use Receive-PSSession if don't want to reconnect eg
## Receive-PSSession -Name Session5 -ComputerName W16CN01
Receive-PSSession -Session $src 

Get-PSSession
Get-PSSession | Remove-PSSession