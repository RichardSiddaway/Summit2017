﻿<#
  Remoting Deep Dive - Summit 2017
    SSH remoting to Linux in PowerShell v6
#>
##
## OPEN IN PowerShell v6 SESSION
##
if ($PSVersionTable.PSVersion.Major -ne 6){
   Throw 'Must be PowerShell v6'
}else{
   Write-Information 'Running in PowerShell v6' -InformationAction Continue
}

##Read-Host -Prompt "press key to continue"

## notice Hostname and SSHConnection
Get-Command New-PSSession -Syntax

## no visible response when type password
$lxs = New-PSSession -HostName Lin01 -UserName root

## create WinRM session to Windows
$ws = New-PSSession -ComputerName W16AS01

## notice Configuration names
Get-PSSession

#using a SSH session
$sb = {Get-ChildItem -Path env:}
Invoke-Command -Session $lxs -ScriptBlock $sb

Invoke-Command -Session $ws -ScriptBlock $sb

## all together now
Invoke-Command -Session $lxs, $ws -ScriptBlock $sb

Invoke-Command -Session $lxs, $ws -ScriptBlock $sb | sort Name

#now add non domain windows