﻿<#
  Remoting Deep Dive - Summit 2017
    Constrained Endpoint - using the endpoint
#>
##
## OPEN IN SEPARATE SESSION
##
## Access as normal
##
$s = New-PSSession -ComputerName W16As01 
Invoke-Command -Session $s -ScriptBlock {Get-Module -ListAvailable}

##  access the constrained endpoint
$sce = New-PSSession -ComputerName W16AS01 -ConfigurationName WSUSRE
Get-PSSession

## what happens here?
Invoke-Command -Session $sce -ScriptBlock {Get-Module -ListAvailable}

## try this
Invoke-Command -Session $sce -ScriptBlock {Get-Command}

## standard restricted commands and UpdateServices module
Invoke-Command -Session $sce -ScriptBlock {Get-WsusComputer}

Get-PSSession | Remove-PSSession

##
## back to W16AS01 for even more retsrictions

##
##  testing the delegated endpoint
##
$cred = Get-Credential -Credential manticore\billgreen

## can't access normal remoting
$sf = New-PSSession -ComputerName W16AS01 -Credential $cred

## accessing delegated endpoint
$sre = New-PSSession -ComputerName W16AS01 -ConfigurationName WSUSdelegated -Credential $cred
Invoke-Command -Session $sre -ScriptBlock {Get-Command}

Invoke-Command -Session $sre -ScriptBlock {Get-WsusComputer}

Invoke-Command -Session $sre -ScriptBlock {Get-WsusUpdate -Approval AnyExceptDeclined}

## even if connect as admin
##  only get restricted cmdlets
$srr = New-PSSession -ComputerName W16AS01 -ConfigurationName WSUSdelegated                                                                     
Invoke-Command -Session $srr -ScriptBlock {Get-Command}

Get-PSSession | Remove-PSSession