﻿<#
  Remoting Deep Dive - Summit 2017
    Removing a JEA end point
#>
##
## OPEN IN SEPARATE SESSION
##   Run **AFTER** PowerShell Web Access demo 
##
Unregister-PSSessionConfiguration -Name JEAWSUSReport -Force
Unregister-PSSessionConfiguration -Name WSUSRE -Force
Unregister-PSSessionConfiguration -Name WSUSdelegated -Force

Get-PSSessionConfiguration | Select-Object Name

Remove-Item -Path 'C:\Program Files\WindowsPowerShell\Modules\WSUSJEA' -Recurse -Force