﻿<#
  Remoting Deep Dive - Summit 2017
    Creating a constrained end point
#>
##
## OPEN IN SEPARATE SESSION
##
# create session configuration
##  do not create through a remoting session
##   can't register the configuration
########################################################################################################################


Set-Location -Path C:\Scripts\RDD-Summit2017


##   create WSUS only endpoint 
##
##  create an endpoint file that only allows access to WSUS cmdlets
##   can restrict PowerShell version using -PowerShellVersion 3.0 
##   only accepts 2.0 & 3.0.  Don't use to get latest version 
New-PSSessionConfigurationFile -Path RestrictedPSWSUS.pssc -LanguageMode Restricted -Description "Access to WSUS cmdlets" `
-ExecutionPolicy Restricted -ModulesToImport UpdateServices  -SessionType RestrictedRemoteServer -VisibleCmdlets *WSUS*

##
## test the configuration
Test-PSSessionConfigurationFile -Path RestrictedPSWSUS.pssc -Verbose

## register the configuration
##  don't use the same name for the config file and the endpoint
Register-PSSessionConfiguration -Path RestrictedPSWSUS.pssc -Force -Name WSUSRE

Get-PSSessionConfiguration | select name

##
##  test from W16TGT01
##

## remove the endpoint
Unregister-PSSessionConfiguration -Name WSUSRE -Force

##
##  now lets restrict the cmdlets AND restrict who can access
##    AND delegate my permissions so they can do so
##    Enabling junior admin to perform a task WITHOUT giving him permissions
##
New-PSSessionConfigurationFile -Path RestrictedWSUS.pssc -LanguageMode Restricted -Description "Access to some WSUS cmdlets only" `
-ExecutionPolicy Restricted -ModulesToImport 'UpdateServices' -SessionType RestrictedRemoteServer  -VisibleCmdlets 'Get-WsusComputer', 'Get-WsusUpdate'

Test-PSSessionConfigurationFile -Path RestrictedWSUS.pssc -Verbose

##
## register endpoint AND set security
##   - give junior admin the rights to 
##     access endpoint  
##   need to add Execute permission  
Register-PSSessionConfiguration -Path RestrictedWSUS.pssc -Name WSUSdelegated -RunAsCredential manticore\richard `
-AccessMode Remote -ShowSecurityDescriptorUI -Force

##
##  test from W16TGT01
##

## remove the endpoint
##   AFTER POWERSHELL WEB ACCESS emo
## use JEA removal scrpt