﻿<#
  Remoting Deep Dive - Summit 2017
    cmdlet based remoting
#>
##
## OPEN IN SEPARATE SESSION
##
Get-Process -ComputerName W16TGT01
Get-WmiObject -Class Win32_OperatingSystem -ComputerName W16TGT01

## firewall can block
## modify firewall on target machine
## repeat commands
Get-Process -ComputerName W16TGT01
Get-WmiObject -Class Win32_OperatingSystem -ComputerName W16TGT01

## run in separate session
##Invoke-Command -ComputerName W16TGT01 -ScriptBlock {Get-Process}
##Get-CimInstance -ClassName win32_operatingsystem -ComputerName W16TGT01

## reset firewall
## repeat commands
Get-Process -ComputerName W16TGT01
Get-WmiObject -Class Win32_OperatingSystem -ComputerName W16TGT01