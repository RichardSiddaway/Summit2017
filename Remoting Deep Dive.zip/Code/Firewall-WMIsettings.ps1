﻿##
##  MAKE SURE FIREWALL IS ACTUALLY RUNNING !!!!!!!!
##


## Block get-Process
Set-NetFirewallRule -DisplayGroup 'File and Printer Sharing' -Enabled True  -Profile Any -Action Block
Get-NetFirewallRule -DisplayGroup 'File and Printer Sharing' | select name, enabled, action

## Block WMI
Set-NetFirewallRule -DisplayGroup 'Windows Management Instrumentation (WMI)' -Profile Any -Enabled True -Action Block
Get-NetFirewallRule -DisplayGroup 'Windows Management Instrumentation (WMI)' | select name, enabled, action


##enable Get-process
Set-NetFirewallRule -DisplayGroup 'File and Printer Sharing' -Enabled True  -Profile Domain -Action Allow

## enable WMI
Set-NetFirewallRule -DisplayGroup 'Windows Management Instrumentation (WMI)' -Action Allow