﻿<#
  Remoting Deep Dive - Summit 2017
    JEA - using the JEA endpoint
#>
##
## OPEN IN SEPARATE SESSION
##
## Access as me
##
$s = New-PSSession -ComputerName W16As01 -ConfigurationName JEAWSUSReport

## need to use account specified
##   doing it this way for demo purposes
##   in relaity the specified user would logon
Get-ADGroupMember -Identity JEA_WSUS_Report
$cred = Get-Credential -Credential 'Manticore\BillGreen'

$s = New-PSSession -ComputerName W16As01 -ConfigurationName JEAWSUSReport -Credential $cred

$sb = {
  Get-Command 
}
Invoke-Command -Session $s -ScriptBlock $sb

$sb = {
  Get-WsusComputer -ComputerTargetGroups 'Windows 2016' 
}
Invoke-Command -Session $s -ScriptBlock $sb

$sb = {
  C:\Scripts\RDD-Summit2017\Get-UpdateStatus.ps1
}
Invoke-Command -Session $s -ScriptBlock $sb 

Remove-PSSession $s