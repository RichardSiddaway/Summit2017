﻿<#
  Remoting Deep Dive - Summit 2017
    PowerShell Direct
    Windows 10/server 2016
    from  Hyper-v host

    use VMname or VMid/VMguid

    my Hyper-V host isn't in the domain

    PowerShell v6/OpenSSH can KILL PowerShell direct
#>
Get-VM | select Name, ID
Remove-Module Hyper-V

## 
Get-Help * -Parameter vmname

## doesn't work with domain credentials
$cred = Get-Credential -Credential W16AS01\Administrator

## can use Invoke-Command directly
Invoke-Command -VMName W16AS01 -Credential $cred -ScriptBlock {Get-Process}

## or use a Remoting session
$s = New-PSSession -VMName W16AS01 -Credential $cred

## notice the Computer type
##  normally RemoteMachine
$s

Invoke-Command -Session $s -ScriptBlock {Get-Process}

Remove-PSSession $s

##
## now try w16TGT01
##   fails because...
$cred = Get-Credential -Credential W16TGT01\Administrator
Invoke-Command -VMName W16TGT01 -Credential $cred -ScriptBlock {Get-Process}

## answer will come later