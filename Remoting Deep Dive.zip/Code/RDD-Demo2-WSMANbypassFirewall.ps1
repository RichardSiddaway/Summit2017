﻿<#
  Remoting Deep Dive - Summit 2017
    using WSMAN to 'bypass' firewall
#>
##
## OPEN IN SEPARATE SESSION
##
Invoke-Command -ComputerName W16TGT01 -ScriptBlock {Get-Process}

Get-CimInstance -ClassName win32_operatingsystem -ComputerName W16TGT01