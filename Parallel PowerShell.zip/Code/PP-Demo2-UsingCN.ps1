﻿<#
  supplying an array to -ComputerName
    easier to code
    still essentially sequential
#>
$computers = Get-ADComputer -Filter * | 
  where DistinguishedName -notlike "*Computer*"  | 
  select -ExpandProperty Name

  Get-HotFix -Id KB3199986 -ComputerName $computers | 
    select PSComputerName, InstalledOn