﻿<#
  using runspaces via PoshRSjobs module
#>
## import module
##   'parallels job cmdlets'
Import-Module -Name PoshRSJob
Get-Command -Module PoshRSJob

$computers = Get-ADComputer -Filter * | 
  where DistinguishedName -notlike "*Computer*"  | 
  select -ExpandProperty Name

<#
     DON'T use foreach - get runspace pool per iteration
     Notice use of {$_}
     use throttle (default 5) to set concurrent runspaces
     scriptblcok parameter is pipeline input !!!
#>
$computers |
   Start-RSJob -Name {"JOB-$_"} -ScriptBlock {
     param ([string]$computer)
     Get-HotFix -Id KB3199986 -ComputerName $computer | 
     select CSName, InstalledOn
  }


<#
  notice only 5 running at a time
  HasMoreData always appears to be false 
#>
Get-RSJob

<#
  Receive-RSjob DOESN'T strip data
#>
foreach ($computer in $computers) {
  Receive-RSjob -Name "JOB-$computer"   
}

## clean up
Get-RSJob | Remove-RSJob