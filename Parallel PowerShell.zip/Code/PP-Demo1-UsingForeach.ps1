﻿<#
  using foreach
    simple to code
    sequential processing
    using Foreach-Object just as sequential
#>
$computers = Get-ADComputer -Filter * | 
  where DistinguishedName -notlike "*Computer*"  | 
  select -ExpandProperty Name

foreach ($computer in $computers) {
  
  Get-HotFix -Id KB3199986 -ComputerName $computer | 
    select PSComputerName, InstalledOn

}

<#
   manual batching 
     run each batch in separate powershell session
     very manual
     could have data in files
     need to modify batches as things change
     resources needed to run!
     collating results difficult
#>
Write-Information -MessageData "Batch 1"  -InformationAction Continue
$computers[0,1] | foreach {
  Get-HotFix -Id KB3199986 -ComputerName $psitem | 
    select PSComputerName, InstalledOn
}

Write-Information -MessageData "`nBatch 2"  -InformationAction Continue
$computers[2,3] | foreach {
  Get-HotFix -Id KB3199986 -ComputerName $psitem | 
    select PSComputerName, InstalledOn
}

Write-Information -MessageData "`nBatch 3"  -InformationAction Continue
$computers[4,5] | foreach {
  Get-HotFix -Id KB3199986 -ComputerName $psitem | 
    select PSComputerName, InstalledOn
}
