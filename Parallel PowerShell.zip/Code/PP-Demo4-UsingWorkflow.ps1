﻿<#
  workflow
    Coding issues:
      PSComputerName for ComputerName
      property names

    output includes extra fields
#>

workflow ppdemo4 {
$computers = Get-ADComputer -Filter * | 
  where DistinguishedName -notlike "*Computer*"  | 
  select -ExpandProperty Name

foreach -parallel ($computer in $computers){

    Get-HotFix -Id KB3199986 -PSComputerName $computer | 
    select CSName, InstalledOn
  
}
}

ppdemo4