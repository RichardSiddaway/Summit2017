﻿<#
  using runspaces
#>

$computers = Get-ADComputer -Filter * | 
  where DistinguishedName -notlike "*Computer*"  | 
  select -ExpandProperty Name

## create runspace pool with min =1 and max = 5 runspaces
$rp = [runspacefactory]::CreateRunspacePool(1,5)

## create powershell and link to runspace pool
$ps = [powershell]::Create()
$ps.RunspacePool = $rp

$rp.Open()

$cmds = New-Object -TypeName System.Collections.ArrayList

$computers | foreach {
  $psa = [powershell]::Create()
  $psa.RunspacePool = $rp

  [void]$psa.AddScript({
     param ($computer)
     
     Get-HotFix -Id KB3199986 -ComputerName $computer | 
     select CSName, InstalledOn

   })

   [void]$psa.AddParameter('computer',"$psitem")
   $handle = $psa.BeginInvoke()

   $temp = '' | select PowerShell, Handle
   $temp.PowerShell = $psa
   $temp.Handle = $handle

   [void]$cmds.Add($temp)
}


## view progress
$cmds | select -ExpandProperty handle

## retreive data
$cmds | foreach {$_.PowerShell.EndInvoke($_.Handle)}

## clean up
$cmds | foreach {$_.PowerShell.Dispose()}  
$rp.Close()
$rp.Dispose() 
