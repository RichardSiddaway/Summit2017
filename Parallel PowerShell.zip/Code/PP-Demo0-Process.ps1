﻿<#
 run in separate powershell session
#>

Get-Process power*

while ($true) {Get-Process -Name power*; ""; Start-Sleep -Seconds 2}