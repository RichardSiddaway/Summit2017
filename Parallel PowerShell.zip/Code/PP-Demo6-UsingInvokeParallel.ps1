﻿<#
  using runspaces via Invoke-Parallel
#>
## import function
##   this should be a module
Set-Location -Path 'C:\Scripts\Parallel PowerShell-Summit2017'
. .\Invoke-Parallel.ps1
Get-ChildItem -Path function:i*

$computers = Get-ADComputer -Filter * | 
  where DistinguishedName -notlike "*Computer*"  | 
  select -ExpandProperty Name

$computers | Invoke-Parallel -ScriptBlock {
       Get-HotFix -Id KB3199986 -ComputerName $psitem | 
     select CSName, InstalledOn

}