﻿<#
  Using jobs
#>
$computers = Get-ADComputer -Filter * | 
  where DistinguishedName -notlike "*Computer*"  | 
  select -ExpandProperty Name

  foreach ($computer in $computers) {
  
  $sb = {
    param ([string]$computer)
     Get-HotFix -Id KB3199986 -ComputerName $computer | 
     select CSName, InstalledOn
  }
  Start-Job -Name "JOB-$computer" -ScriptBlock $sb -ArgumentList $computer 

}

Get-Job

foreach ($computer in $computers) {
  Receive-Job -Name "JOB-$computer" -Keep
}

Get-Job | Remove-Job